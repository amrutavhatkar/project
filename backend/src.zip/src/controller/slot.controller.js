// const Slot = require('../model/slotSchema');
const db =  require('../model/slotSchema');
const Slot = db.Slot;

exports.findAll =  (req,res)=>{
    Slot.find()
    .then(slots => {
        res.json(slots);
    }).catch(err =>{
        res.status(500).send({
            msg:err.message
        });
    });
};

exports.createSlot = (req,res)=>{
    const {name,email,phone,time} = req.body;
    if(!name || !email || !phone || !time){
        return res.status(402).json({error:'please fill the property'});
    }
    console.log(req.body);
    const slot = new Slot ({ name, email, phone, time });
    slot.save().then(() => {
            res.status(201).json({ message: "slot booked succesfully" });
            }).catch((err) => res.status(500).json({ error: "failed to book" }));
};
